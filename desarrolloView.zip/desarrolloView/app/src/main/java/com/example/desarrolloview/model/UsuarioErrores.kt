package com.example.desarrolloview.model

data class UsuarioErrores(
    val nombre: String? = null,
    val correo: String? = null,
    val clave:  String? = null,
    val direccion: String? = null
)